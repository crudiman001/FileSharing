#!/bin/ksh
# ======================================================
#  Modify the variables below to match your environment.
# ======================================================

openpages_domain_folder="/home/opuser/OP/OpenPages/bin"

login_username="OpenPagesAdministrator"
login_password="OpenPagesAdministrator"

# ======================================================

loader_list_file="loader-data/objectManagerLoad.txt"
